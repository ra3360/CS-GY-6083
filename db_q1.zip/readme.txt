Extract the folder "db_q1" to "..\xampp\htdocs\"

Enter the following url in the web browser: http://localhost/db_q1

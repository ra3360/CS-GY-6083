<?php

/**
  * Function to query information based on
  * a parameter: in this case, nationality.
  *
  */

if (isset($_POST['submit'])) {
  try {
    require "config.php";
    require "common.php";

    $connection = new PDO($dsn, $username, $password, $options);

    $sql = "SELECT a.artistName, a.nationality, al.albumName, al.releaseTime FROM artist a, album al, song s, SongInAlbum sia
WHERE a.nationality = :nationality AND sia.sid=s.sid AND s.artistId=a.artistId AND al.albumId = sia.albumId
GROUP BY a.artistName;";

    $nationality = $_POST['nationality'];

    $statement = $connection->prepare($sql);
    $statement->bindParam(':nationality', $nationality, PDO::PARAM_STR);
    $statement->execute();

    $result = $statement->fetchAll();
  } catch(PDOException $error) {
    echo $sql . "<br>" . $error->getMessage();
  }
}
?>
<?php require "templates/header.php"; ?>

<?php
if (isset($_POST['submit'])) {
  if ($result && $statement->rowCount() > 0) { ?>
    <h2>Results</h2>

    <table>
      <thead>
<tr>
  <th>Artist Name</th>
  <th>Nationality</th>
  <th>Album Name</th>
  <th>Release Time</th>
</tr>
      </thead>
      <tbody>
  <?php 
  
  foreach ($result as $row) { ?>
      <tr>
<td><?php $link="http://localhost/db_q1/".escape($row["artistName"])."/"; echo "<a href=$link>".escape($row["artistName"])."</a>"; ?></td>
<td><?php echo escape($row["nationality"]); ?></td>
<td><?php echo escape($row["albumName"]); ?></td>
<td><?php echo escape($row["releaseTime"]); ?></td>


      </tr>
    <?php } ?>
      </tbody>
  </table>
  <?php } else { ?>
    > No results found for <?php echo escape($_POST['nationality']); ?>.
  <?php }
} ?>

    <h2>Type in the nationality of the artist</h2>

    <form method="post">
    	<label for="nationality">Nationality</label>
    	<input type="text" id="nationality" name="nationality">
    	<input type="submit" name="submit" value="View Results">
    </form>


<?php require "templates/footer.php"; ?>

<?php require "templates/header.php"; ?>

<?php


	$hostname="localhost";
	$username="root";
	$password="";
	$databaseName="q1";
	
	$connect = mysqli_connect($hostname, $username, $password, $databaseName);
	
	$query = "SELECT s.sname, s.language, s.style, s.duration, s.releaseTime FROM song s, artist a WHERE a.artistID=s.artistId AND a.artistName='Laura Fygi'
Order BY s.releaseTime DESC, s.sname
;";
	
	$result = mysqli_query($connect, $query);
	echo"<table border='1'>";
	echo"<tr><th>Song Name</th><th>Language</th><th>Style</th><th>Duration</th><th>Release Time</th><tr>";
	while ($row = mysqli_fetch_assoc($result)) {
        echo"<tr><td>{$row['sname']}</td><td>{$row['language']}</td><td>{$row['style']}</td><td>{$row['duration']}</td><td>{$row['releaseTime']}</td><tr>";
	
		
	}
	echo"</table>";
	
?>	


 